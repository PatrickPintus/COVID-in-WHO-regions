############# 16x6 graphs Figure

# Upload series ee.dp.AFR  & ee.pm.AFR from  file ee.AFR.fig5.dat 
# Upload series ee.dp.AMR  & ee.pm.AMR from  file ee.AMR.fig5.dat 
# Upload series ee.dp.EUR  & ee.pm.EUR from  file ee.EUR.fig5.dat 
# Upload series ee.dp.SEAR & ee.pm.SEAR from  file ee.SEAR.fig5.dat
# Upload series ee.dp.EMR  & ee.pm.EMR from  file ee.EMR.fig5.dat 
# Upload series ee.dp.WPR  & ee.pm.WPR from  file ee.WPR.fig5.dat 

xx.1 <- ee.dp.AFR[9:98]   # Raw Infection Acc. Indice
yy.1 <- ee.pm.AFR[9:98]   # Raw Mortality Acc. Indice

xx.2 <- ee.dp.AMR[10:103] # Raw Infection Acc. Indice
yy.2 <- ee.pm.AMR[10:103] # Raw Mortality Acc. Indice


xx.3 <- ee.dp.EUR[5:99]   # Raw Infection Acc. Indice
yy.3 <- ee.pm.EUR[5:99]   # Raw Mortality Acc. Indice

xx.4 <- ee.dp.SEAR[9:102] # Raw Infection Acc. Indice
yy.4 <- ee.pm.SEAR[9:102] # Raw Mortality Acc. Indice

xx.5 <- ee.dp.EMR[8:99] # Raw Infection Acc. Indice
yy.5 <- ee.pm.EMR[8:99] # Raw Mortality Acc. Indice

xx.6 <- ee.dp.WPR[4:100] # Raw Infection Acc. Indice
yy.6 <- ee.pm.WPR[4:100] # Raw Mortality Acc. Indice

sc <- 3

pdf(file = "coupling-All.2.pdf",width=7*sc,height=19*sc)  
par(mar=c(0,3,3,0)+1) # c(bottom, left, top, right)
par(mfrow=c(6,1))


par(mfrow=c(16,6))
par(mar = c(1, 1, 1, 1))

ss.1 <- length(xx.1)
ss.2 <- length(xx.2)
ss.3 <- length(xx.3)
ss.4 <- length(xx.4)
ss.5 <- length(xx.5)
ss.6 <- length(xx.6)

stars <- c("","*","**")

for (i in 1:16){
    # AFR
    plot(xx.1[1:(ss.1-i)],
         yy.1[(1+i):ss.1],
         lwd=2,col="blue",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.1[1:(ss.1-i)], yy.1[(1+i):ss.1]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.1[1:(ss.1-i)],yy.1[(1+i):ss.1],
                             method="kendall"),2),
         cex=4,col="black")
    # AMR
    plot(xx.2[1:(ss.2-i)],
         yy.2[(1+i):ss.2],
         lwd=2,col="darkorchid",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.2[1:(ss.2-i)], yy.2[(1+i):ss.2]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.2[1:(ss.2-i)],yy.2[(1+i):ss.2],
                             method="kendall"),2),
         cex=4,col="black")
    # EUR
    plot(xx.3[1:(ss.3-i)],
         yy.3[(1+i):ss.3],
         lwd=2,col="orange",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.3[1:(ss.3-i)], yy.3[(1+i):ss.3]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.3[1:(ss.3-i)],yy.3[(1+i):ss.3],
                             method="kendall"),2),
         cex=4,col="black")
    # SEAR
    plot(xx.4[1:(ss.4-i)],
         yy.4[(1+i):ss.4],
         lwd=2,col="darkolivegreen",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.4[1:(ss.4-i)], yy.4[(1+i):ss.4]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.4[1:(ss.4-i)],yy.4[(1+i):ss.4],
                             method="kendall"),2),
         cex=4,col="black")
    # EMR
    plot(xx.5[1:(ss.5-i)],
         yy.5[(1+i):ss.5],
         lwd=2,col="darkgoldenrod",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.5[1:(ss.5-i)], yy.5[(1+i):ss.5]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.5[1:(ss.5-i)],yy.5[(1+i):ss.5],
                             method="kendall"),2),
         cex=4,col="black")
    # WPR
    plot(xx.6[1:(ss.6-i)],
         yy.6[(1+i):ss.6],
         lwd=2,col="magenta",
         cex=2,cex.lab=3,cex.axis=3,xlim=c(0,4),
        ylim=c(0,4),type="p",
        ylab="",xlab="",xaxt="n",yaxt="n")
    lines(lowess(xx.6[1:(ss.6-i)], yy.6[(1+i):ss.6]),
          lwd=6,col = "red")
    lines(c(0,1,1),c(1,1,0),lwd=3)
    lines(c(1,1,3.5),c(3.5,1,1),lwd=3)
    text(x=3, y = 3, labels = round(
                         cor(xx.6[1:(ss.6-i)],yy.6[(1+i):ss.6],
                             method="kendall"),2),
         cex=4,col="black")
}

dev.off()
